package org.example.routtoproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RouttoProjectApplication {

    public static void main(String[] args) {
        SpringApplication.run(RouttoProjectApplication.class, args);
    }

}
