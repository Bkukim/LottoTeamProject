<template>
  <div class="container">
    <div class="row justify-content-end">
      <div class="col mt-5">
        <br>
      
        <h2>오늘의 할일</h2>
        <hr>
      </div>
      <div class="col-auto mt-5">
        <div class="btn-group-vertical">
          <div id="right-box1"></div>
          <div id="right-box2"></div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {};
</script>
<style>
#right-box1 {
  border: 1px solid white;
  background-color: #342a26;
  width: 18.6458vw;
  height: 21.0938vw;
  color: white;
}
#right-box2 {
  border: 1px solid white;
  background-color: #342a26;
  width: 18.6458vw;
  height: 16.875vw;
  color: white;
}
</style>
