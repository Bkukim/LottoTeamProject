<template>
    <div>
        <div>
            <h1>마이 페이지</h1>
        </div>
        <div>
            보유 마일리지 {값} + 조회버튼 /
            보유 쿠폰 {값} + 조회버튼
        </div>
        <div>
            나의 주문 처리 현황 (최근 3개월 기준) + 3개월단위 날짜 표기
        </div>
        <div>
            박스
            <div> 오른쪽 가로
                <div>입금 전 {값}</div>
                <div>배송 준비중 {값}</div>
                <div>배송중 {값}</div>
                <div>배송완료 {값}</div>
                // 오른쪽 가로 끝
            </div>
            <div>왼쪽 사이드 세로
                <div>취소 {값}</div>
                <div>교환 {값}</div>
                <div>반품 {값}</div>
                // 왼쪽 사이드 세로 끝
            </div>
            박스 끝//
        </div>

        <div>주문 내역 조회</div>
        <div>회원정보 수정</div>
        <div>관심 상품</div>
        <div>즐겨찾기</div>
        <div>리뷰 페이지</div>
        <div>주소록 관리</div>
    </div>
</template>
<script>
export default {

}
</script>
<style></style>