<template>
  <!-- 전체 중앙정렬 -->
  <div class="frame-22">
    <!-- 메인배너 -->
    <img class="baner_divbox" src="@/assets/images/main_banner.jpg" />
    <!-- src="@/assets/images/main_banner.jpg -->

    <!-- product -->
    <div class="product">
      <!--  product 메뉴 버튼-->
      <div class="menu_bt">
        <div class="frame-18">
          <div class="all">ALL</div>
        </div>
        <div class="frame-19">
          <div class="skin">BEST</div>
        </div>
        <div class="frame-20">
          <div class="body">SKIN</div>
        </div>
        <div class="frame-21">
          <div class="make-up">BODY</div>
        </div>
      </div>
    </div>

    <!-- best product2 상품 -->

    <!-- product2_all 전체박스 -->
    <div class="product2_all">
    <!-- product 왼쪽 문구 -->
      <div class="product2">product</div>
      <div class="product2_in">
        <div class="div10">
          <div class="_23"></div>
          <div class="_24"></div>
          <div class="abcdefghijklm">
            <p>루또 네추럴 파운데이션</p>
          </div>
          <div class="abcdefghijklm2">
            <p>완벽밀착! 자연스럽고 매끄러운 피부</p>
          </div>
          <div class="abcdef">36,800 won</div>
          <div class="frame-11"></div>
        </div>
        <div class="div10">
          <div class="_25"></div>
          <div class="_26"></div>
          <div class="abcdefghijklm3">루또 체인지 립밤 2종</div>
          <div class="abcdefghijklm4">보습과 생기 컬러 립밤</div>
          <div class="abcdef2">11,900 won</div>
          <div class="frame-112"></div>
        </div>
        <div class="div10">
          <div class="_27"></div>
          <div class="_28"></div>
          <div class="abcdefghijklm5">페이스 라인 스틱</div>
          <div class="abcdefghijklm6">얼굴을 또력하고 슬림하게</div>
          <div class="abcdef3">15,900 won</div>
          <div class="frame-113"></div>
        </div>
        <div class="div10">
          <div class="_29"></div>
          <div class="_210"></div>
          <div class="abcdefghijklm7">멜로우 클레이 포마드</div>
          <div class="abcdefghijklm8">자연스러운 헤어 포마드</div>
          <div class="abcdef4">16,900 won</div>
          <div class="frame-114"></div>
        </div>
      </div>
    </div>

    <!-- best-sellers -->
    <div class="best-menu">
      <img class="_1" />
      <div class="best-menu_in">
        <img class="div8" />
        <img class="div9" />
        <div class="best-menu2">BEST SELLERS</div>
        <div class="abcdefgefgefdfdfsfdadffddfsd">
          가장 사랑 받고 있는 루또의 베스트 제품
        </div>
        <div class="abcdefgefghijk4">
          <p>내추럴 커버 파운데이션</p>
        </div>
        <div class="abcdefg">shop</div>
        <div class="abcdefgefghijk5">퍼펙트 옴므 쿠션</div>
        <div class="abcdefg2">shop</div>
      </div>
    </div>

    
    
      <img class="_2" />

      <div class="best-menu-2">
      <div class="_22">
        <img class="div2" />
        <div class="abcdefgefghijk">Texture Curl Cream</div>
        <div class="div3">쉽고 빠른 스타일링, 모발 케어 성분은 물론
향기까지 완벽한 
프리미엄 퍼퓸 컬크림</div>
        <div class="shop-more">SHOP MORE &gt;</div>
      </div>
      <div class="_22">
        <img class="div4" />
        <div class="abcdefgefghijk2">All In One! Essence</div>
        <div class="div5">진정 / 보습장벽 / 모공 / 피지케어까지 한번에
남성 피부 맞춤 올인원 솔루션</div>
        <div class="shop-more2">SHOP MORE &gt;</div>
      </div>
      <div class="_22">
        <img class="div6" />
        <div class="abcdefgefghijk3">Style! Setting Fixer</div>
        <div class="div7">자연스러운 헤어 고정, 탈모완화기능성은 물론
향기까지 완벽한 프리미엄 퍼퓸 픽서</div>
        <div class="shop-more3">SHOP MORE &gt;</div>
      </div>
    </div>

    <!-- 전체 중앙정렬 -->
  </div>
</template>
<script>
export default {};
</script>
<style>
@import "@/assets/css/main.css";
</style>
