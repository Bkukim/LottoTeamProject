<template>
  <div>
    <div class="btn-group-vertical">
      <button type="button" class="sidebar-btn">버튼 1</button>
      <button type="button" class="sidebar-btn">버튼 1</button>
      <button type="button" class="sidebar-btn">버튼 1</button>
      <button type="button" class="sidebar-btn">버튼 1</button>
      <button type="button" class="sidebar-btn">버튼 1</button>
      <button type="button" class="sidebar-btn">버튼 1</button>
      <button type="button" class="sidebar-btn">버튼 1</button>
      <button type="button" class="sidebar-btn">버튼 1</button>
      <button type="button" class="sidebar-btn">버튼 1</button>
    </div>
  </div>
</template>
<script>
export default {};
</script>
<style>
.sidebar-btn {
  background-color: #342a26;
  width:  18.6458vw;
  height: 4.2187vw;
  border: 1px solid white ;
  color: white;
}
</style>
