<template>
    <div class="footer">
        <div class="afe-24">
          <p> Permit Registration : 2017-SeoulGangnam-04392 </p>
          <br />
          <p> Fax : 02-6952-3376 ｜ Personal Information Manager : JEON Yong Kweon I </p>
          Mail : cs@adaptkorea.com
          <br />
          <p> Copyright. OBGE All right reserved. Hosting by cafe24.</p>
        </div>
        <div class="link">
          <span>
            <span class="link-span">이용안내 I 이용약관 I</span>
            <span class="link-span2">개인정보처리방침</span>
          </span>
        </div>
        <div class="group-20">
          <div class="group-19">
            <div class="_02-1234-5678">02 1234 5678</div>
            <div class="_10-00-17-00-lunch-time-12-30-14-00">
              <p>10:00~ 17:00</p>
              <br />
              <p>(Lunch time 12:30~14:00)</p>
            </div>
            <div class="div11">토, 일요일 및 공휴일 휴무</div>
            <div class="bank-info">Bank Info</div>
            <div class="div12">그린은행 / 주식회사 루또</div>
          </div>
          <div class="_1005-112-000000">1005-112-000000</div>
        </div>
        <img class="routto-3-4" src="routto-3-40.png" />
      </div>
  </template>
  <script>
  export default {
      
  }
  </script>
  <style>
      @import '@/assets/css/footer.css';
  </style>
  